
import React, { useState } from 'react';
import './App.css';

function App() {
  const [peso, setPeso] = useState('');
  const [altura, setAltura] = useState('');
  const [imc, setImc] = useState(null);
  const [categoria, setCategoria] = useState('');

  const calcularIMC = () => {
    if (peso && altura) {
      const imcCalculado = (peso / (altura * altura)).toFixed(2);
      setImc(imcCalculado);
      classificarIMC(imcCalculado);
    }
  };

  const classificarIMC = (imc) => {
    const valor = parseFloat(imc);

    if (valor < 18.5) {
      setCategoria('Baixo peso');
    } else if (valor >= 18.5 && valor <= 24.9) {
      setCategoria('Peso Normal');
    } else if (valor >= 25 && valor <= 29.9) {
      setCategoria('Excesso de peso');
    } else if (valor >= 30 && valor <= 34.9) {
      setCategoria('Obesidade de classe 1');
    } else if (valor >= 35 && valor <= 39.9) {
      setCategoria('Obesidade de classe 2');
    } else if (valor >= 40) {
      setCategoria('Obesidade de classe 3');
    }
  };

  return (
    <div className="container">
      <h1>Calculadora de IMC</h1>

      <input
        type="number"
        placeholder="Peso (kg)"
        value={peso}
        onChange={(e) => setPeso(e.target.value)}
      />

      <input
        type="number"
        placeholder="Altura (m)"
        value={altura}
        onChange={(e) => setAltura(e.target.value)}
      />

      <button onClick={calcularIMC}>Calcular IMC</button>

      {imc && (
        <div className="resultado">
          <p><strong>Seu IMC:</strong> {imc}</p>
          <p><strong>Categoria:</strong> {categoria}</p>
        </div>
      )}
    </div>
  );
}

export default App;
